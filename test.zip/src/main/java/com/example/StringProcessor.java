package com.example;

public class StringProcessor {

    /**
     * Removes consecutive characters that appear 3 or more times.
     *
     * @param input The input string.
     * @return The processed string.
     */
    public static String removeConsecutiveChars(String input) {

        StringBuilder sb = new StringBuilder(input);
        int length = sb.length();
        int i = 0,tmp = 1;
        char tmpchar=' ';
        while (i < length) {
            char currentChar = sb.charAt(i);
            if(currentChar == tmpchar){
                tmp++;
            }else{
                if(tmp >= 3){
                    sb.delete(i-tmp, i);
                    i -=tmp;
                    length -= tmp;
                }
                tmp = 1;
            }
            i++;
            tmpchar =currentChar;
        }
        String re = "";
        if(!input.equals(sb.toString())){
            System.out.println("->"+sb.toString());
            re = removeConsecutiveChars(sb.toString());
            return re;
        }
        return sb.toString();

    }

    /**
     * Replaces consecutive characters that appear 3 or more times with the previous character.
     *
     * @param input The input string.
     * @return The processed string.
     */
    public static String replaceConsecutiveChars(String input) {
        StringBuilder sb = new StringBuilder(input);
        int length = sb.length();
        int i = 0,tmp = 1;
        char tmpchar=' ';
        String tmpmsg="";
        while (i < length) {
            char currentChar = sb.charAt(i);
            if(currentChar == tmpchar){
                tmp++;
            }else{
                if(tmp >= 3){
                    char prevChar = (i > 0) ? (char)(sb.charAt(i - 1)-1) : (char)('a' - 1);
                    if (prevChar == 'a' - 1) {
                        prevChar = ' ';
                    }
                    String tmpmsgStr = String.valueOf(sb.charAt(i - 1)).repeat(tmp);
                    sb.delete(i-tmp, i);
                    if(prevChar!=' '){
                        tmpmsg += "," + tmpmsgStr + " is replaced by " + prevChar;
                        sb.insert(i-tmp, prevChar);
                        length -= (tmp-1);
                        i -=(tmp-1);
                    }else{
                        length -= tmp;
                        i -=tmp;
                    }


                }
                tmp = 1;
            }
            i++;
            tmpchar =currentChar;
        }
        String re = "";
        if(!input.equals(sb.toString().trim())){
            System.out.println("->"+sb.toString().trim()+tmpmsg);
            re = replaceConsecutiveChars(sb.toString().trim());
            return re;
        }
        return sb.toString().trim();

    }

    public static void main(String[] args) {
        removeConsecutiveChars("aabcccbbad"); // d
        System.out.println("----");
        replaceConsecutiveChars("bbbccaaabbad");

    }
}
