package com.example;

public class StringProcessor {
    public static String removeConsecutiveCharacters(String s) {
        StringBuilder sb = new StringBuilder();
        int count = 1;
        for (int i = 1; i <= s.length(); i++) {
            if (i < s.length() && s.charAt(i) == s.charAt(i - 1)) {
                count++;
            } else {
                if (count < 3) {
                    for (int j = 0; j < count; j++) {
                        sb.append(s.charAt(i - 1));
                    }
                }
                count = 1;
            }
        }
        return sb.toString();
    }

    public static String replaceConsecutiveCharacters(String s) {
        StringBuilder sb = new StringBuilder();
        int count = 1;
        for (int i = 1; i <= s.length(); i++) {
            if (i < s.length() && s.charAt(i) == s.charAt(i - 1)) {
                count++;
            } else {
                if (count >= 3) {
                    sb.append((char) (s.charAt(i - 1) - 1));
                } else {
                    for (int j = 0; j < count; j++) {
                        sb.append(s.charAt(i - 1));
                    }
                }
                count = 1;
            }
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        System.out.println(removeConsecutiveCharacters("aabcccbbad")); // d
        System.out.println(replaceConsecutiveCharacters("abcccbad")); // d
    }
}
