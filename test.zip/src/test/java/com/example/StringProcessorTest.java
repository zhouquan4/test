package com.example;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class StringProcessorTest {

    @Test
    public void testRemoveConsecutiveCharacters() {
        assertEquals("", StringProcessor.removeConsecutiveCharacters(""));
        assertEquals("a", StringProcessor.removeConsecutiveCharacters("aaa"));
        assertEquals("d", StringProcessor.removeConsecutiveCharacters("aabcccbbad"));
        assertEquals("d", StringProcessor.removeConsecutiveCharacters("aaad"));
    }

    @Test
    public void testReplaceConsecutiveCharacters() {
        assertEquals("", StringProcessor.replaceConsecutiveCharacters(""));
        assertEquals("b", StringProcessor.replaceConsecutiveCharacters("ccc"));
        assertEquals("a", StringProcessor.replaceConsecutiveCharacters("bbb"));
        assertEquals("d", StringProcessor.replaceConsecutiveCharacters("abcccbad"));
    }
}
