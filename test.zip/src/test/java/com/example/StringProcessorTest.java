package com.example;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class StringProcessorTest {

    @Test
    public void testRemoveConsecutiveCharacters() {
        assertEquals("d", StringProcessor.removeConsecutiveChars("aabcccbbad"));
        assertEquals("d", StringProcessor.removeConsecutiveChars("aabcccccbbad"));
        assertEquals("bccbbad", StringProcessor.removeConsecutiveChars("aaabccbbad"));
        assertEquals("aa", StringProcessor.removeConsecutiveChars("aa"));
    }

    @Test
    public void testReplaceConsecutiveCharacters() {
        assertEquals("d", StringProcessor.replaceConsecutiveChars("aabcccbbad"));
        assertEquals("d", StringProcessor.replaceConsecutiveChars("aabcccccbbad"));
        assertEquals("bccbbad", StringProcessor.replaceConsecutiveChars("aaabccbbad"));
        assertEquals("accbbad", StringProcessor.replaceConsecutiveChars("bbbccaaabbad"));
        assertEquals("aa", StringProcessor.replaceConsecutiveChars("aa"));
    }
}
